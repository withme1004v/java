import java.lang.*;
public class Round02_Ex01 {
	public static void main(String[] ar) {
		System.out.println("Hello Java!");		
	}
}
