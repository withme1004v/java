	public class Round03_Ex02{
		public static void main(String[] ar){
			int x = 0;
			System.out.println(x);
		}
	}
