	public class Round03_Ex03{
		int x;
		public static void main(String[] ar){
			Round03_Ex03 rd = new Round03_Ex03();
			System.out.println(rd.x);
		}
	} 
