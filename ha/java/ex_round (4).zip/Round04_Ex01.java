public class Round04_Ex01 {
	public static void main(String[] ar) {
		System.out.println("ABC");
		System.out.println();
		System.out.println("DEF");
	}
}
