public class Round04_Ex02 {
	public static void main(String[] ar) {
		byte by = 12;
		System.out.println(by);
		short sh = 12;
		System.out.println(sh);
		char ch = 12;
		System.out.println(ch);
		int i = 12;
		System.out.println(i);
		long lo = 12L;
		System.out.println(lo);
		float fl = 12.0f;
		System.out.println(fl);
		double dou = 12.0;
		System.out.println(dou);
	}
}
