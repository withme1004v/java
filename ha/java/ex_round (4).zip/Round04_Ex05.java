import java.io.*;
public class Round04_Ex05 {
	public static void main(String[] ar) throws IOException {
		byte[] bb = { 'J', 'A', 'V', 'A' };
		System.out.write(bb);
	}
}
