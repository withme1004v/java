public class Round04_Ex08 {
	public static void main(String[] ar) throws java.io.IOException {
		System.out.print("�Է� = "); // println �ƴ�.
		int aa = System.in.read();
		int bb = System.in.read();
		int cc = System.in.read();
		int dd = System.in.read();
		int ee = System.in.read();
		System.out.println("aa = " + aa);
		System.out.println("bb = " + bb);
		System.out.println("cc = " + cc);
		System.out.println("dd = " + dd);
		System.out.println("ee = " + ee);
	}
}
