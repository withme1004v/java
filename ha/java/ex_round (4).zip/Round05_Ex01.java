public class Round05_Ex01 {
	public static void main(String[] ar) {
		int x = 5;
		int y = ++x;
		System.out.println("x = " + x);
		System.out.println("y = " + y);
	}
}
