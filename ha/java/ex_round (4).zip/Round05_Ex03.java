public class Round05_Ex03 {
	public static void main(String[] ar) {
		float f = 1.2f;
		double d = 1.2;
		double dd = d - f;
		System.out.println(dd);
	}
}
