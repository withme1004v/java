public class Round08_Ex01 {
	public static void main(String[] ar) {
		System.out.println("ar[0] = " + ar[0]);
		System.out.println("ar[1] = " + ar[1]);
		System.out.println("ar[2] = " + ar[2]);
	}
}
