public class Round08_Ex02 {
	public static void main(String[] ar) {
		if (ar.length != 1) {
			System.out.println("Usage : java Round08_02 ����");
			System.exit(1);
		}
		int x = Integer.parseInt(ar[0]);
		System.out.println("�Էµ� �� = " + x);
	}
}
