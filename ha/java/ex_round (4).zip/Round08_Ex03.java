public class Round08_Ex03 {
	public static void main(String[] ar) {
		for (int i = 0; i < ar.length; i++) {
			System.out.println(i + "��° ���� = " + ar[i]);
		}
	}
}
