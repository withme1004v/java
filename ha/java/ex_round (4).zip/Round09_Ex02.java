public class Round09_Ex02 {
	int a;

	int b;

	float c;

	public static void main(String[] ar) {
		Round09_Ex02 kor1 = null;
		kor1 = new Round09_Ex02();
		kor1.a = 100;
		kor1.b = 200;
		kor1.c = 300.0f;
		System.out.println("a = " + kor1.a);
		System.out.println("b = " + kor1.b);
		System.out.println("c = " + kor1.c);
	}
}
