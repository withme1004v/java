public class Round10_Ex01 {
	private int x = 10;

	public static void main(String[] ar) {
		Round10_Ex01 rd = new Round10_Ex01();
		System.out.println("x = " + rd.x);
	}
}
