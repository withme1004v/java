class Round10_Ex02_Other {
	private int x = 10;
}

public class Round10_Ex02 {
	public static void main(String[] ar) {
		Round10_Ex02_Other rd = new Round10_Ex02_Other();
		//System.out.println("x = " + rd.x);
	}
}
