class Round10_Ex03_Other {
	protected int x = 10;
}

public class Round10_Ex03 {
	public static void main(String[] ar) {
		Round10_Ex03_Other rd = new Round10_Ex03_Other();
		System.out.println("x = " + rd.x);
	}
}
