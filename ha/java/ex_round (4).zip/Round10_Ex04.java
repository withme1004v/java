	public class Round10_Ex04{
		protected int x = 10;
	}
