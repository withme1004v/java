public class Round10_Ex05 {
	public static void main(String[] ar) {
		Round10_Ex04 rd = new Round10_Ex04();
		System.out.println("x = " + rd.x);
	}
}
