public class Round10_Ex06 {
	int x = 10;
}
