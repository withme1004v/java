public class Round10_Ex07 {
	public static void main(String[] ar) {
		Round10_Ex06 rd = new Round10_Ex06();
		System.out.println("x = " + rd.x);
	}
}
