import java.io.*;

public class Round10_Ex09 {
	public static void main(String[] ar) throws IOException {
		Round10_Ex08 rd = new Round10_Ex08();
		rd.setName();
		rd.setJumin();
		rd.display();
	}
}
