import java.io.*;

public class Round11_Ex03 {
	public static void main(String[] ar) throws IOException {
		Round11_Ex02 rd = new Round11_Ex02();
		System.out.println();
		System.out.print("������ ");
		System.out.println(Round11_Ex02.getTot());
		System.out.println();
		rd.display();
	}
}
