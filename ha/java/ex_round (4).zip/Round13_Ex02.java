class Inherit2 {
	public String toString() {
		return "Ŭ���� Inherit";
	}
}

public class Round13_Ex02 {
	public static void main(String[] ar) {
		Inherit2 in = new Inherit2();
		System.out.println("��ü ��� = " + in);
	}
}
