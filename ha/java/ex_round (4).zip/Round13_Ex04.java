class A {
	private int x = 100;

	private int y = 200;
}

class B extends A {
	private int r = 300;
}

public class Round13_Ex04 {
	public static void main(String[] ar) {
		B bp = new B();
	}
}
