import kimsh.util.*;
public class Round15_Ex13 {
	public static void main(String[] ar) {
		Round15_Ex12 ts = new Round15_Ex12();
		kimsh.util.Round15_Ex12 ts1 = new kimsh.util.Round15_Ex12(); // ���� ��θ���
		ts.disp();
		ts1.disp();
	}
}
