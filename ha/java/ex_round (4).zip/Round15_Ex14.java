public class Round15_Ex14 {
	public static void main(String[] args) {
		byte a = Byte.MAX_VALUE;
		byte b = Byte.MIN_VALUE;
		System.out.println("a = " + a);//127
		System.out.println("b = " + b);//-128				
	}
}
