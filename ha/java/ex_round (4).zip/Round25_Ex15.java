import java.rmi.*;

public interface Round25_Ex15 extends Remote {
	public String sayHello() throws RemoteException;	
	public void printDate() throws RemoteException;
}
