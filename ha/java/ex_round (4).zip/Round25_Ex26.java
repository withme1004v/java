import java.rmi.*;

public interface Round25_Ex26 extends Remote {
	public String sayHello(String name) throws RemoteException;
}
