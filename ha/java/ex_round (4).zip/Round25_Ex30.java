import java.rmi.*;

public interface Round25_Ex30 extends Remote {
	public void setClient(Round25_Ex31 cf) throws RemoteException;

	public void setDate() throws RemoteException;
}
