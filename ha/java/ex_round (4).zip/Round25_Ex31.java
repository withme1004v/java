import java.rmi.*;

public interface Round25_Ex31 extends Remote {
	public void setScreenDate(String str) throws RemoteException;
}
