import java.rmi.*;

public interface Round25_Ex35 extends Remote {
	public void setMessage(String msg) throws RemoteException;
}
